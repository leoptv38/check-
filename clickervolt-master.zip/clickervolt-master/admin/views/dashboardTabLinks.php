<div id="tab-links" class="tab-content current">
    <span class="links-toolbar" style="display: none;">
        <button id="btn-links-refresh" class="button button-primary"><i class="material-icons for-button refresh"></i>Refresh</button>
        <input class="daterange" type="text" name="links-daterange" readonly />
        <select class="heatmap" for="#datatables-links"></select>
    </span>
    <table id="datatables-links" class="reporting-table stats-table-with-fixed-header"></table>
</div>