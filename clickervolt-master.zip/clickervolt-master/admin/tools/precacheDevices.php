<?php

namespace ClickerVolt;

require_once __DIR__ . '/../../utils/deviceDetection.php';

DeviceDetection::reCache();
