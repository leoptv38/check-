<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar7');
class TableStatsWholePathVar7 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 7;
    }
}
