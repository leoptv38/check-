<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar6');
class TableStatsWholePathVar6 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 6;
    }
}
