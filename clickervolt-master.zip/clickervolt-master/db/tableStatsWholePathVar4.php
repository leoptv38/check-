<?php

namespace ClickerVolt;

require_once __DIR__ . '/tableStatsWholePathVarX.php';

TableStats::registerClass('ClickerVolt\\TableStatsWholePathVar4');
class TableStatsWholePathVar4 extends TableStatsWholePathVarX
{

    public function getVarNumber()
    {
        return 4;
    }
}
